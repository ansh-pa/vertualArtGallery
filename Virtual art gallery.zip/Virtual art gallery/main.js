const menuBox = document.getElementById('menuBox');
const menuIcon = document.getElementById('menuIcon');

menuIcon.addEventListener('click', () =>{
    menuBox.classList.toggle('hide');
    menuIcon.classList.toggle('rotate');
    menuIcon.src = menuIcon.src.endsWith('menu.png') ? 'images/close.png' : 'images/menu.png';
});